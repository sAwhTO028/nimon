import 'package:flutter/material.dart';
import 'community_card_new.dart';
import 'community_models.dart';
import 'community_constants.dart';

class CommunitySection extends StatelessWidget {
  final List<CommunityCardVM> communities;
  final ValueChanged<CommunityCardVM>? onCardTap;
  final ValueChanged<CommunityEpisodeVM>? onEpisodeTap;
  final VoidCallback? onSeeAllTap;

  const CommunitySection({
    super.key,
    required this.communities,
    this.onCardTap,
    this.onEpisodeTap,
    this.onSeeAllTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Column(
      children: [
        // Section Header
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
          child: Row(
            children: [
              Text(
                'From the Community',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.15,
                  height: 1.27,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const Spacer(),
              // "See all" button
              Material(
                color: theme.colorScheme.primaryContainer.withOpacity(0.08),
                borderRadius: BorderRadius.circular(20),
                child: InkWell(
                  onTap: onSeeAllTap,
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    height: 36,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Center(
                      child: Text(
                        'See all >',
                        style: theme.textTheme.labelLarge?.copyWith(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        // Horizontal carousel
        SizedBox(
          height: CommDims.cardHeight(),
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: communities.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              final community = communities[index];
              return SizedBox(
                width: MediaQuery.of(context).size.width * 0.88, // Keep some peek
                child: CommunityCard(
                  vm: community,
                  onCardTap: () => onCardTap?.call(community),
                  onEpisodeTap: onEpisodeTap,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}
