import 'package:flutter/material.dart';
import 'community_models.dart';
import 'community_constants.dart';

class CommunityCard extends StatelessWidget {
  final CommunityCardVM vm;
  final VoidCallback? onCardTap;
  final ValueChanged<CommunityEpisodeVM>? onEpisodeTap;

  const CommunityCard({
    super.key,
    required this.vm,
    this.onCardTap,
    this.onEpisodeTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(
        textScaler: const TextScaler.linear(1.0), // Cap text scale to prevent height drift
      ),
      child: Container(
        height: CommDims.cardHeight(),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.colorScheme.outlineVariant),
          boxShadow: [
            BoxShadow(
              blurRadius: 18,
              offset: const Offset(0, 10),
              color: Colors.black.withOpacity(0.06),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onCardTap,
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(CommDims.vPad),
              child: Column(
                children: [
                  // Header (fixed height)
                  SizedBox(
                    height: CommDims.headerH,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Book cover
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.network(
                            vm.coverUrl,
                            width: 84,
                            height: CommDims.headerH,
                            fit: BoxFit.cover,
                            gaplessPlayback: true,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Container(
                                width: 84,
                                height: CommDims.headerH,
                                color: theme.colorScheme.surfaceContainerLow,
                                child: const Center(
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                ),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                width: 84,
                                height: CommDims.headerH,
                                color: theme.colorScheme.surfaceContainerLow,
                                child: const Center(
                                  child: Icon(Icons.book, size: 24, color: Colors.grey),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        // Title/desc/meta + Level pill
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Title + Level chip
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      vm.title,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: theme.textTheme.titleLarge?.copyWith(
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: theme.colorScheme.primaryContainer,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      vm.level,
                                      style: theme.textTheme.labelSmall?.copyWith(
                                        color: theme.colorScheme.onPrimaryContainer,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              // Meta line
                              Text(
                                'by Community Writers',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.labelSmall?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                              const SizedBox(height: 4),
                              // Description
                              Expanded(
                                child: Text(
                                  vm.description,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    height: 1.3,
                                  ),
                                ),
                              ),
                              // Footer row
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Story type – ${vm.genre}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: theme.textTheme.labelMedium?.copyWith(
                                        color: theme.colorScheme.onSurfaceVariant,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'Episodes ${vm.totalEpisodes}',
                                    style: theme.textTheme.labelMedium?.copyWith(
                                      color: theme.colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: CommDims.rowGap),
                  // Episode rows (exactly 3)
                  ...vm.episodes.take(3).toList().asMap().entries.map((entry) {
                    final episode = entry.value;
                    final isFirst = entry.key == 0;
                    
                    return Container(
                      height: CommDims.rowH,
                      margin: EdgeInsets.only(top: isFirst ? 0 : CommDims.rowGap),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: theme.colorScheme.outlineVariant),
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => onEpisodeTap?.call(episode),
                          borderRadius: BorderRadius.circular(12),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Row(
                              children: [
                                // Episode thumbnail
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    episode.thumb,
                                    width: 44,
                                    height: 44,
                                    fit: BoxFit.cover,
                                    gaplessPlayback: true,
                                    loadingBuilder: (context, child, loadingProgress) {
                                      if (loadingProgress == null) return child;
                                      return Container(
                                        width: 44,
                                        height: 44,
                                        color: theme.colorScheme.surfaceContainerLow,
                                        child: const Center(
                                          child: CircularProgressIndicator(strokeWidth: 1),
                                        ),
                                      );
                                    },
                                    errorBuilder: (context, error, stackTrace) {
                                      return Container(
                                        width: 44,
                                        height: 44,
                                        color: theme.colorScheme.surfaceContainerLow,
                                        child: const Center(
                                          child: Icon(Icons.play_circle_outline, size: 16, color: Colors.grey),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(width: 12),
                                // Episode content
                                Expanded(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        episode.title,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: theme.textTheme.titleSmall?.copyWith(
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      Text(
                                        'Episode ${episode.number}',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: theme.textTheme.labelSmall?.copyWith(
                                          color: theme.colorScheme.onSurfaceVariant,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // Chevron
                                Icon(
                                  Icons.chevron_right_rounded,
                                  size: 20,
                                  color: theme.colorScheme.onSurfaceVariant.withOpacity(0.6),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
