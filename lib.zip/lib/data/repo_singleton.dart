import 'package:nimon/data/story_repo.dart';
import 'package:nimon/data/story_repo_mock.dart';

// single shared instance used across the app
final StoryRepo repo = StoryRepoMock();
